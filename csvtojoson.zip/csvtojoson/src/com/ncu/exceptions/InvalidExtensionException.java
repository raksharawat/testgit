package com.ncu.exceptions;

public class InvalidExtensionException extends Exception{
	public InvalidExtensionException(String s){
		super(s);
	}
}	