package com.ncu.exceptions;

public class MissingExtensionException extends Exception{
	public MissingExtensionException(String s){
		super(s);
	}
}	