package com.ncu.exceptions;

public class EmptyFileNameException extends Exception{
	public EmptyFileNameException(String s){
		super(s);
	}
}	