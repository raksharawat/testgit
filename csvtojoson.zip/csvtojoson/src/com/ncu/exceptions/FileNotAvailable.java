package com.ncu.exceptions;

public class FileNotAvailable extends Exception{
	public FileNotAvailable(String s){
		super(s);
	}
}	