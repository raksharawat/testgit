package com.ncu.exceptions;

public class EmptyExtensionException extends Exception{
	public EmptyExtensionException(String s){
		super(s);
	}
}	