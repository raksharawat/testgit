package com.ncu.exceptions;

public class NotJsonFileException extends Exception{
	public NotJsonFileException(String s){
		super(s);
	}
}	