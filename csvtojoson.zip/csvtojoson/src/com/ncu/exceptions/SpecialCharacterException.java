package com.ncu.exceptions;

public class SpecialCharacterException extends Exception{
	public SpecialCharacterException (String s){
		super(s);
	}
}	