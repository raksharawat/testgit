package com.ncu.exceptions;

public class FileNameLengthException extends Exception{
	 public FileNameLengthException(String s){
		super(s);
	}
}	