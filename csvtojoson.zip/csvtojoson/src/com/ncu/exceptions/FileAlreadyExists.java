package com.ncu.exceptions;

public class FileAlreadyExists extends Exception{
	public FileAlreadyExists(String s){
		super(s);
	}
}	